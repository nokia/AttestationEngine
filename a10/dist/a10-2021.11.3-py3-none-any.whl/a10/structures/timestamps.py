# Copyright 2021 Nokia
# Licensed under the BSD 3-Clause License.
# SPDX-License-Identifier: BSD-3-Clause

import datetime

def now():
	n=datetime.datetime.now(datetime.timezone.utc)
	return str(n.timestamp())

import datetime

def now():
	n=datetime.datetime.now(datetime.timezone.utc)
	return str(n.timestamp())
